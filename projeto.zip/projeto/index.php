<?php
#Base de dados
include('conecta.php');

#Cabeçalho
include('header.php');

#conteúdo da página
include('home.php');

#rodapé
include('footer.php');

?>