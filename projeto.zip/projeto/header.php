<!DOCTYPE html>
<html>
	<head>
		<title>CRUD PHP</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/estilo.css">
	</head>
	<body>
		<header>
			<img src="" title="Logo" alt="Logo">
			<div id="menu"></div>
		</header>
		<div id="conteudo">
		<!--Aqui se encontra somente até o cabeçalho da página, onde a div será fechada em footer.php-->