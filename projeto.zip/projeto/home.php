<?php

echo 'Olá mundo';

?>